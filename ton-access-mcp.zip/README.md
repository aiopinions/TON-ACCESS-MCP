# TON Access Model Context Protocol (MCP)

This repository contains a Model Context Protocol (MCP) for the [ton-access](https://github.com/orbs-network/ton-access) library, which provides unthrottled anonymous RPC access to the TON blockchain via a robust decentralized network.

## Overview

The TON Access MCP is designed to help AI models understand and interact with the `ton-access` library, enabling them to provide more accurate and helpful assistance to developers working with the TON blockchain.

## Repository Contents

- **[ton-access-mcp-design.md](./ton-access-mcp-design.md)**: Comprehensive design document outlining the library's purpose, components, and usage patterns.
- **[ton-access-mcp.ts](./ton-access-mcp.ts)**: TypeScript implementation of the MCP that mirrors the original library's API with detailed documentation.
- **[ton-access-mcp-documentation.md](./ton-access-mcp-documentation.md)**: Detailed documentation for the MCP, including API reference and usage examples.
- **[ton-access-mcp-validation.ts](./ton-access-mcp-validation.ts)**: Validation script to test the MCP implementation.

## Purpose

The TON Access MCP serves as a bridge between AI models and the `ton-access` library, enabling models to:

1. Understand the structure and functionality of the library
2. Generate accurate code examples for developers
3. Provide helpful troubleshooting assistance
4. Explain complex concepts related to TON blockchain access

## Key Features

The MCP covers all key aspects of the `ton-access` library:

- Multiple endpoint types (TonCenter HTTP API v2, TonHub HTTP API v4, and ADNL Proxy)
- Network selection (mainnet/testnet)
- Node health checking and selection
- Weighted random load balancing across healthy nodes

## Usage

The MCP is designed to be used by AI models to understand the `ton-access` library. Developers should use the actual `ton-access` library in their projects:

```typescript
// For AI model understanding (MCP)
import { getHttpEndpoint } from './ton-access-mcp';

// For actual development
import { getHttpEndpoint } from '@orbs-network/ton-access';
```

## Getting Started

To explore the MCP:

1. Start with the [design document](./ton-access-mcp-design.md) for a high-level overview
2. Review the [TypeScript implementation](./ton-access-mcp.ts) for detailed API
3. Consult the [documentation](./ton-access-mcp-documentation.md) for usage examples
4. Run the [validation script](./ton-access-mcp-validation.ts) to see the MCP in action

## Original Library

For the actual `ton-access` library, visit the [official repository](https://github.com/orbs-network/ton-access).
